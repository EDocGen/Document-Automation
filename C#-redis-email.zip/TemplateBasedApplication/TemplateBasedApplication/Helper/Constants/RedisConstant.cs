﻿namespace TemplateBasedApplication.Helper.Constants
{
    public class RedisConstant
    {
        public const string PDF_GENERATOR_TOKEN = "tokenKey";
    }
}
