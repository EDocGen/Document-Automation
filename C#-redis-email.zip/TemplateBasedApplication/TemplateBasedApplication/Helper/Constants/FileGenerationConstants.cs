﻿namespace TemplateBasedApplication.Helper.Constants
{
    public class FileGenerationConstants
    {
        public const string DEFAULT_TEMPLATE_ID = "636df1afe369c25651bc5d0b";
        public const string PDF_OUTPUT_FORMAT = "pdf";
        public const string ZIP_OUTPUT_FORMAT = "zip";
    }
}
