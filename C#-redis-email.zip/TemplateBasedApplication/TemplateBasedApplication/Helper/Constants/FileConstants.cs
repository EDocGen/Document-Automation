﻿namespace TemplateBasedApplication.Helper.Constants
{
    public class FileConstants
    {
        public const string FILE_SAVE_FOLDER_PATH = @"./Sources/";
    }
}
