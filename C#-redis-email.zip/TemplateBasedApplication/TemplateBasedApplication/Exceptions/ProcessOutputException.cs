﻿using System;

namespace TemplateBasedApplication.Exceptions
{
    public class ProcessOutputException : Exception
    {
        public ProcessOutputException(string message):base(message)
        {

        }
    }
}
