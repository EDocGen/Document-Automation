﻿namespace TemplateBasedApplication.Models
{
    public class FileRequestModel
    {
        public string token { get; set; }
        public string fileName { get; set; }
        public string filePath { get; set; }
    }
}
