﻿namespace TemplateBasedApplication.Models.Dto
{
    public class AuthenticationDto
    {
        public string token { get; set; }
    }
}
