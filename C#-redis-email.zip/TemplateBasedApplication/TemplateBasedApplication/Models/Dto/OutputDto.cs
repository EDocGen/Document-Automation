﻿namespace TemplateBasedApplication.Models.Dto
{
    public class OutputDto
    {
        public string _id { get; set; }
    }
}
